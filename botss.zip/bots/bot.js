const {VK} = require('vk-io'); 
const {Keyboard} = require('vk-io');
const vk = new VK(); 
const {updates, api, snippets} = vk; 
const fs = require('fs');
const { upload } = vk;
const request = require('request-promise');
const chalk = require('chalk');
const mobs = require('./mobs.json')
const base = require('./base.json')
const beseda = require('./beseda.json')

const parser = require('fast-xml-parser');

const { createCanvas, loadImage } = require('canvas')
const canvas = createCanvas(800, 800)
const Canvas = require('canvas');
const ctx = canvas.getContext('2d')
const path = require('path')

function near(x, y, objectx, objecty) {
	let near = false
	x -= Number(objectx)
	y -= Number(objecty)
	if(x < 0) x = -x
	if(y < 0) y = -y
	if(x < 30 && y < 50) near = true
	return near
}

function rand(text) {
	let tts = Math.floor(text.length * Math.random())
	return text[tts]
}

setInterval(function(){ 
        fs.writeFileSync("./mobs.json", JSON.stringify(mobs, null, "\t")) 
}, 10000); // обновление базы данных

setInterval(function(){ 
        fs.writeFileSync("./beseda.json", JSON.stringify(beseda, null, "\t")) 
}, 10000); // обновление базы данных

setInterval(function(){ 
        fs.writeFileSync("./base.json", JSON.stringify(base, null, "\t")) 
}, 10000); // обновление базы данных

const rotateText = {
	0: "0⃣",
	1: "1⃣",
	2: "2⃣",
	3: "3⃣",
	4: "4⃣",
	5: "5⃣",
	6: "6⃣",
	7: "7⃣",
	8: "8⃣",
	9: "9⃣"
}

function nols(num) {
    if(num < 10) return('0' + num)
    if(num > 9) return(num)
}

function zapret(text) {
 	let text1 = text.toLowerCase();
 	let texts = 0;
 	let stat = false;
	var zaprets = /(пизда|ебут в жопу|соска|соски|сосёт|мамка|мамки|брат с сестрой|сперма|ебалка|вк бо т |сова не спит|сова никогда не спит|с о в а н е с п и т|сованикогданеспит|сова не спит никогда|вкботру|vkvot ru|vkbotru|vkbot|v k b o t . r u|в к бот|порно|botvk|ботвк|vkbot|кбот|bot vk|хентай|секс|пидр|трах|насилие|зоофил|бдсм|сирия|hentai|hentay|синий кит|самоубийство|террористы|слив|цп|cp|маленькие|малолетки|сучки|трах|ебля|изнасилование|блять|хуй|пошел нах|тварь|мразь|сучка|гандон|уебок|шлюх|паскуда|оргазм|девственницы|целки|рассовое|мелкие|малолетки|несовершеннолетние|ебля|хентай|sex|bdsm|ebl|trax|syka|shlux|инцест|iznas|мать|долбаеб|долбаёб|хуесос|сучка|сука|тварь|пездюк|хуй|шлюх|бог|сатана|мразь)/
	if (zaprets.test(text1) == true) { 
		texts = `📗 ➾ Некорректный запрос.` 
		stat = true;
	}
	var filter1 = /(http(s)?:\/\/.)?(www\.)?[-a-z0-9@:%._\+~#=]{1,256}\.[a-z]{2,6}/
	var filter2 = /(?!http(s)?:\/\/)?(www\.)?[а-я0-9-_.]{1,256}\.(рф|срб|блог|бг|укр|рус|қаз|امارات.|مصر.|السعودية.)/ 
	if (filter1.test(text1) == true || filter2.test(text1) == true) { 
		texts = `📗 ➾ Некорректный запрос.` 
		stat = true; 
	}
	return texts
 } 

function splitString(stringToSplit, separator) {
	var arrayOfStrings = stringToSplit.split(separator);
	return arrayOfStrings
}

const utils = { 
sp: (int) => { 
int = int.toString(); 
return int.split('').reverse().join('').match(/[0-9]{1,3}/g).join(',').split('').reverse().join(''); 
},
	random: (x, y) => {
		return y ? Math.round(Math.random() * (y - x)) + x : Math.round(Math.random() * x);
	},
pick: (array) => {
	return array[getRandomInRange(array.length - 1)];
}}

function getRandomInRange(min, max) { 
return Math.floor(Math.random() * (max - min + 1)) + min; 
}; //Функция выбора рандомного числа

vk.setOptions({ 
	token: "e0ddeb8de8de17bef9d50a2b282d5deda0677fcc4c94693685193dcd2621b641137e6888bebd83d0a403b", 
	apiMode: "parallel", 
	pollingGroupId: 189875029
});

setInterval(function(){
	if(base.c.trees < 10){
		let kordsx = [Number(getRandomInRange(1600, 2000)), Number(getRandomInRange(830, 1170))]
		let kordsy = [Number(getRandomInRange(550, 1070)), Number(getRandomInRange(550, 800))]
		let random = getRandomInRange(1, 2)
		base.c.treesid += Number(1)
		base.c.trees += 1
		if(random == 1){
			mobs.objects.tree[base.c.treesid] = {
				coordsx: Number(kordsx[0]),
				coordsy: Number(kordsy[0]),
				hp: 10,
				dead: 0,
				hpp: 0
			}
		}
		if(random == 2){
			mobs.objects.tree[base.c.treesid] = {
				coordsx: Number(kordsx[1]),
				coordsy: Number(kordsy[1]),
				hp: 10,
				dead: 0,
				hpp: 0
			}
		}
	}
}, 20000)

vk.updates.use(async (context, next) => {
	if(context.isOutbox) return
	if(context.isGroup) return
	if(context.senderId === undefined) return
	if(!base.i[context.senderId]){
		var ctxs 
		base.c.id += 1
		base.i[context.senderId] = {
			id: base.c.id
		}
		let users = await vk.api.users.get({
			user_id: context.senderId,
			fields: 'photo_50'
		})
		base.p[base.c.id] = {
			exp: 0,
			lvl: 1,
			worlds: 0,
			caseopen: 0,
			balance: 0,
			rank: 0,
			photo_50: `${users[0].photo_50}`,
			lvl: 1,
			inventory: {
				wood: 0
			},
			world: {
				x: 1352,
				y: 687
			},
			id: context.senderId,
			cent: 0,
			nick: `${users[0].last_name}`
		}
		context.send({
		message: `Спасибо за регистрацию в боте, для обучения подойдите к "NPC Лаура".`,
		keyboard: Keyboard.keyboard([
			[
				Keyboard.textButton({
					label: `🔨`,
					color: Keyboard.NEGATIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⬆`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `Инвентарь`,
					color: Keyboard.NEGATIVE_COLOR
				})
			],
			[
				Keyboard.textButton({
					label: `⬅`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⚔`
				}),
				Keyboard.textButton({
					label: `➡`,
					color: Keyboard.POSITIVE_COLOR
				})
			],
			[
				Keyboard.textButton({
					label: `⠀`,
					color: Keyboard.NEGATIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⬇`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⠀`,
					color: Keyboard.NEGATIVE_COLOR
				})
			]
		])
	})
		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
		let xplayers = Number(base.p[base.i[context.senderId].id].world.x)
		let yplayers = Number(base.p[base.i[context.senderId].id].world.y)
	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }

	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

		return context.sendPhotos(canvass.toBuffer())
	}
    await next();
});

updates.hear(/создатьпеременнуючисло (.*) (.*)/i, async (context) => {
	if(base.p[base.i[context.senderId].id].rank < 10) return
	for(let i in base.p){
		base.p[i][context.$match[1]] = Number(context.$match[2])
	}
	return context.send(`всё`)
})

updates.hear(/создатьпеременнуюстрока (.*) (.*)/i, async (context) => {
	if(base.bs[base.id[context.senderId].id].rank < 10) return
	for(let i in base.p){
		base.p[i][context.$match[1]] = `${context.$match[2]}`
	}
	return context.send(`всё`)
})

updates.hear(/кн/i, async (context) => {
	return context.send({
		message: `>> Открываю клавиатуру.`,
		//message: `⛄ Все команды: \n>> статус (все теги)\n>> статус "статус" (установить статус)\n >> статус вкл (выключить/включить авто-статус)\n>> рандом (посмотреть команды связанные с рандом статусом)\n >> отвязать (отвязать токен)`,
		//⠀
		keyboard: Keyboard.keyboard([
			[
				Keyboard.textButton({
					label: `🔨`,
					color: Keyboard.NEGATIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⬆`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `Инвентарь`,
					color: Keyboard.NEGATIVE_COLOR
				})
			],
			[
				Keyboard.textButton({
					label: `⬅`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⚔`
				}),
				Keyboard.textButton({
					label: `➡`,
					color: Keyboard.POSITIVE_COLOR
				})
			],
			[
				Keyboard.textButton({
					label: `⠀`,
					color: Keyboard.NEGATIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⬇`,
					color: Keyboard.POSITIVE_COLOR
				}),
				Keyboard.textButton({
					label: `⠀`,
					color: Keyboard.NEGATIVE_COLOR
				})
			]
		])
	})	
})

updates.hear(/🔨/i, async (context) => {
		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	let xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	let yplayers = Number(base.p[base.i[context.senderId].id].world.y)
	let put = -10
	for(let i in mobs.objects.tree){
		if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		   	put = i
		}
	}
	if(put == -10) {
		context.send(`Поблизости с вами не было найдено объектов (подойдите в плотную)`)
	} else {
	mobs.objects.tree[put].hp -= 2
	if(mobs.objects.tree[put].hp < 1){
	 delete mobs.objects.tree[put]
	 base.c.trees -= 1
	 base.p[base.i[context.senderId].id].inventory.wood += Number(getRandomInRange(1, 3))
	 context.send(`Вы успешно срубили дерево №${put}`)
	} else {
		context.send(`Вы успешно рубите дерево №${put}.\nПрочность дерева: ${mobs.objects.tree[put].hp}🛡`)
	}
}

	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }

	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

		return context.sendPhotos(canvass.toBuffer())
})

updates.hear(/инвентарь/i, async (context) => {
		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	let xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	let yplayers = Number(base.p[base.i[context.senderId].id].world.y)
	for(let i in mobs.objects.tree){
		if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		   	put = i
		}
	}
	for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }
	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }



	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

		img.src = 'inventory.png';
	    ctxs.drawImage(img, 432, 15) // (-433, -459)-83

	    var count = 0
	    var coordx = 0
	    var coordy = 0

	    if(base.p[base.i[context.senderId].id].inventory.wood > 0){
	    	count += 1
	    	if(count > 0) {
	    		coordy = 58
	    		coordx = Number(count)
	    	}
	    	if(count > 4) {
				coordy = 108
				coordx = Number(count-4)
			}
	    	if(count > 8) {
	    		coordy = 166
	    		coordx = Number(count-8)
	    	}
	    	if(count > 12) {
	    		coordy = 220
	    		coordx = Number(count-12)
	    	}
	    	if(count > 16) {
	    		coordy = 274
	    		coordx = Number(count-16)
	    	}
	    	if(count > 20) {
	    		coordy = 328
	    		coordx = Number(count-20)
	    	}
	    	if(coordx == 1){
	    		coordx = 441
	    	}
	    	if(coordx == 2){
	    		coordx = 494
	    	}
	    	if(coordx == 3){
	    		coordx = 548
	    	}
	    	if(coordx == 4){
	    		coordx = 601
	    	}
	    	console.log(coordx)
	    	img.src = 'wood.png';
	    	ctxs.drawImage(img, coordx, coordy)
			ctxs.font = 'bold 10px sans';
	    	ctxs.fillStyle = "#ffffff";
			//ctx.textAlign = 'center';
			coordy += 44
			ctxs.fillText(`${base.p[base.i[context.senderId].id].inventory.wood}шт.`, coordx, coordy);
	    }

		return context.sendPhotos(canvass.toBuffer())
})

updates.hear(/тест/i, async (context) => {
	if(base.p[base.i[context.senderId].id].worlds === 0){
		var xplayers = Number(base.p[base.i[context.senderId].id].world.x)
		var yplayers = Number(base.p[base.i[context.senderId].id].world.y)
		let text = `Рядом с вами:`
		let count = 0

		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	    
	    for(let i in mobs.objects.tree){
		    if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		    	if(count > 0) text += `, дерево`
		    	if(count == 0){
		    		count += 1
		    		text += `дерево`
		    	}
		    }
	    }


		for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }
	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }



	    

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

		console.log(base.p[base.i[context.senderId].id].photo_50)

		yplayers = await loadImage(base.p[base.i[context.senderId].id].photo_50)
		ctxs.drawImage(yplayers, 2, 2)

		img.src = `gui.png`;
		ctxs.drawImage(img, 0, 0)
		
		ctxs.font = '15px canvas';
	    ctxs.fillStyle = "#e0e0e0";
		ctxs.textAlign = 'center';
		ctxs.fillText(`${base.p[base.i[context.senderId].id].lvl}`, 47, 54);

		if(count === 0) return context.sendPhotos(canvass.toBuffer())
		if(count > 0) return context.sendPhotos({
			value: canvass.toBuffer()
		}, {
			message: `${text}`
		})
	}
})


updates.hear(/ник (.*)/i, async (context) => {
	if(context.$match[1].length > 15) return context.send(`Слишком большое кол-во символов в нике.`)
	base.p[base.i[context.senderId].id].nick = `${context.$match[1]}`
	return context.send(`Ник успешно установлен!`)
})

updates.hear(/телепорт/i, async (context) => {
if(base.p[base.i[context.senderId].id].worlds === 0){
	base.p[base.i[context.senderId].id].x = 1250
	base.p[base.i[context.senderId].id].y = 1250

		var xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	var yplayers = Number(base.p[base.i[context.senderId].id].world.y)

	const { registerFont, createCanvas, loadImage } = require('canvas');
	registerFont('canvas.ttf', { family: 'canvas' })
	var canvas = createCanvas(2500, 2500);
	var ctx = canvas.getContext('2d');
	var Image = Canvas.Image;
	var img = new Image();
	img.src = 'pole.png';
    ctx.drawImage(img, 0, 0) // (-433, -459)-83

    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

    for(let i in base.p){
    	let x = base.p[i].world.x
    	let y = base.p[i].world.y
    	if(base.p[i].cent === 0) img.src = 'guard.png'
    	if(base.p[i].cent === 1) img.src = 'guard1.png'
    	ctx.drawImage(img, x, y)
    	let xnick = base.p[i].world.x+17
    	let ynick = base.p[i].world.y-5
    	ctx.font = 'bold 13px sans';
    	ctx.fillStyle = "#ffffff";
		ctx.textAlign = 'center';
		ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
    }

    var dataUrl = canvas.toDataURL();

    img.src = `${dataUrl}`;

    var canvass = createCanvas(700, 400);
	var ctxs = canvass.getContext('2d');

	xplayers = Math.floor(xplayers-330)
	xplayers = -xplayers

	yplayers = Math.floor(yplayers-178)
	yplayers = -yplayers

    ctxs.drawImage(img, xplayers, yplayers)

	ctxs.font = '30px canvas';
   	ctxs.fillStyle = "#751404";
	//ctx.textAlign = '';
	ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

return context.sendPhotos(canvass.toBuffer())
}
})


updates.hear(/⬅/i, async (context) => {
if(base.p[base.i[context.senderId].id].worlds === 0){

	var xplayers = Number(base.p[base.i[context.senderId].id].world.x-20)
	if(xplayers < 721) {
		context.send(`Вы не можете выйти за границу карты!`)
	} else {
	base.p[base.i[context.senderId].id].world.x -= 20
	}
	base.p[base.i[context.senderId].id].cent = 1

	var yplayers = Number(base.p[base.i[context.senderId].id].world.y+20)


	xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	yplayers = Number(base.p[base.i[context.senderId].id].world.y)

let text = `Рядом с вами:`
		let count = 0

		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	    
	    for(let i in mobs.objects.tree){
		    if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		    	if(count > 0) text += `, дерево`
		    	if(count == 0){
		    		count += 1
		    		text += `дерево`
		    	}
		    }
	    }

	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }



	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);

		if(count < 1) return context.sendPhotos(canvass.toBuffer())
		if(count > 0){
			return context.sendPhotos({
				value: canvass.toBuffer()
			}, {
				message: `${text}`
			})
		}
}})

updates.hear(/⬇/i, async (context) => {
if(base.p[base.i[context.senderId].id].worlds === 0){
	var yplayers = Number(base.p[base.i[context.senderId].id].world.y+20)
	if(yplayers > 1900) {
		context.send(`Вы не можете выйти за границу карты!`)
	} else {
		base.p[base.i[context.senderId].id].world.y += 20
	}


	var xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	yplayers = Number(base.p[base.i[context.senderId].id].world.y)

	let text = `Рядом с вами:`
		let count = 0

		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	    
	    for(let i in mobs.objects.tree){
		    if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		    	if(count > 0) text += `, дерево`
		    	if(count == 0){
		    		count += 1
		    		text += `дерево`
		    	}
		    }
	    }

for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }


	    	   ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);
		
		if(count === 0) return context.sendPhotos(canvass.toBuffer())
		if(count > 0) return context.sendPhotos({
			value: canvass.toBuffer()
		}, {
			message: `${text}`
		})
}})

updates.hear(/⬆/i, async (context) => {
if(base.p[base.i[context.senderId].id].worlds === 0){
	var yplayers = Number(base.p[base.i[context.senderId].id].world.y)
	console.log(yplayers)
	if(yplayers < 390) {
		context.send(`Вы не можете выйти за границу карты!`)
	} else {
		base.p[base.i[context.senderId].id].world.y -= 20
	}



	var xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	yplayers = Number(base.p[base.i[context.senderId].id].world.y)

	let text = `Рядом с вами:`
		let count = 0

		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	    
	    for(let i in mobs.objects.tree){
		    if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		    	if(count > 0) text += `, дерево`
		    	if(count == 0){
		    		count += 1
		    		text += `дерево`
		    	}
		    }
	    }
	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }


	    	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);
		
		if(count === 0) return context.sendPhotos(canvass.toBuffer())
		if(count > 0) return context.sendPhotos({
			value: canvass.toBuffer()
		}, {
			message: `${text}`
		})}})

updates.hear(/➡/i, async (context) => {
if(base.p[base.i[context.senderId].id].worlds === 0){

	var xplayers = Number(base.p[base.i[context.senderId].id].world.x+20)
	if(xplayers > 2035) {
		context.send(`Вы не можете выйти за границу карты!`)
	} else {
		base.p[base.i[context.senderId].id].world.x += 20
	}

	var yplayers = Number(base.p[base.i[context.senderId].id].world.y+20)

	base.p[base.i[context.senderId].id].cent = 0



	xplayers = Number(base.p[base.i[context.senderId].id].world.x)
	yplayers = Number(base.p[base.i[context.senderId].id].world.y)

let text = `Рядом с вами:`
		let count = 0

		const { registerFont, createCanvas, loadImage } = require('canvas');
		registerFont('canvas.ttf', { family: 'canvas' })
		var canvas = createCanvas(2773, 2235);
		var ctx = canvas.getContext('2d');
		var Image = Canvas.Image;
		var img = new Image();
		img.src = 'pole.png';
	    ctx.drawImage(img, 0, 0) // (-433, -459)-83
	    
	    for(let i in mobs.objects.tree){
		    if(near(xplayers, yplayers, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy) == true) {
		    	if(count > 0) text += `, дерево`
		    	if(count == 0){
		    		count += 1
		    		text += `дерево`
		    	}
		    }
	    }

	    for(let i in mobs.objects.tree){
	    	if(mobs.objects.tree[i].dead === 0){
				var img = new Image();
				img.src = 'tree.png';
	    		ctx.drawImage(img, mobs.objects.tree[i].coordsx, mobs.objects.tree[i].coordsy)
	    	}
	    }

	    for(let i in base.p){
	    	let x = base.p[i].world.x
	    	let y = base.p[i].world.y
	    	if(base.p[i].cent === 0) img.src = 'guard.png'
	    	if(base.p[i].cent === 1) img.src = 'guard1.png'
	    	ctx.drawImage(img, x, y)
	    	let xnick = base.p[i].world.x+17
	    	let ynick = base.p[i].world.y-5
	    	ctx.font = 'bold 13px sans';
	    	ctx.fillStyle = "#ffffff";
			ctx.textAlign = 'center';
			ctx.fillText(`${base.p[i].nick}`, xnick, ynick);
	    }


	    	    	ctx.font = 'bold 15px canvas';
	    	ctx.fillStyle = "#ffec18";
			ctx.textAlign = 'center';
			ctx.fillText(`Лаура`, 1297, 683);

	    var dataUrl = canvas.toDataURL();

	    img.src = `${dataUrl}`;

	    var canvass = createCanvas(700, 400);
		var ctxs = canvass.getContext('2d');

		xplayers = Math.floor(xplayers-330)
		xplayers = -xplayers

		yplayers = Math.floor(yplayers-178)
		yplayers = -yplayers

	    ctxs.drawImage(img, xplayers, yplayers)

		ctxs.font = '30px canvas';
	   	ctxs.fillStyle = "#751404";
		//ctx.textAlign = '';
		ctxs.fillText(`X: ${base.p[base.i[context.senderId].id].world.x}, Y: ${base.p[base.i[context.senderId].id].world.y}`, 518, 386);
		
		if(count === 0) return context.sendPhotos(canvass.toBuffer())
		if(count > 0) return context.sendPhotos({
			value: canvass.toBuffer()
		}, {
			message: `${text}`
		})}
})




updates.hear(/eval/i, async (context) => {
	if(base.bs[base.id[context.senderId].id].rank < 10) return
	let text = `${context.text}`
	text = text.replace(`eval `, ``)
	await eval(text)
})



vk.updates.hear(/кейсы 1/i, async (context) => {
	if(base.p[base.i[context.senderId].id].caseopen === 1) return
	const { createCanvas, loadImage } = require('canvas');
	const canvas = createCanvas(1920, 1080);
	const ctx = canvas.getContext('2d');
	const Image = Canvas.Image;
	const img = new Image();
	let random = [rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`]), rand([`vip.png`, `exp.png`, `exp.png`, `banan.png`, `banan.png`, `banan.png`])]
	let random1 = getRandomInRange(5,5)
	img.src = 'case.png';
	ctx.drawImage(img, 0, 0);
	base.p[base.i[context.senderId].id].caseopen = 1
	if(random1 === 5){
		context.send(`>> открываю кейс`).then(res => {
			var idmessage = res
				let imgs = new Image()
				imgs.src = `${random[0]}` // 1 массив
				ctx.drawImage(imgs, 1263, 324) // 1 массив
				upload.messagePhoto({
					peer_id: context.senderId,
					source: canvas.toBuffer()
				}).then(id => {
					vk.api.messages.edit({
						peer_id: context.senderId,
						message_id: res,
						attachment: `photo${id.ownerId}_${id.id}_${id.accesKey}`
					})
				})
				setTimeout(() => {
					let img = new Image();
					img.src = 'case.png';
					ctx.drawImage(img, 0, 0);

					let imgs = new Image()
					imgs.src = `${random[0]}` // 1 массив
					ctx.drawImage(imgs, 745, 324) // 239 324

					let imgt = new Image()
					imgt.src = `${random[1]}` // 2 массив
					ctx.drawImage(imgt, 1263, 324)

					upload.messagePhoto({
						peer_id: context.senderId,
						source: canvas.toBuffer()
					}).then(id => {
						vk.api.messages.edit({
							peer_id: context.senderId,
							message_id: res,
							attachment: `photo${id.ownerId}_${id.id}_${id.accesKey}`
						})
					})
					setTimeout(() => {
						let img = new Image();
						img.src = 'case.png';
						ctx.drawImage(img, 0, 0);

						let imgs = new Image()
						imgs.src = `${random[0]}` // 1 массив
						ctx.drawImage(imgs, 239, 324)

						let imgt = new Image()
						imgt.src = `${random[1]}` // 2 массив
						ctx.drawImage(imgt, 745, 324)

						let imgp = new Image()
						imgp.src = `${random[2]}` // 3 массив
						ctx.drawImage(imgp, 1263, 324)

						upload.messagePhoto({
							peer_id: context.senderId,
							source: canvas.toBuffer()
						}).then(id => {
							vk.api.messages.edit({
								peer_id: context.senderId,
								message_id: res,
								attachment: `photo${id.ownerId}_${id.id}_${id.accesKey}`
							})
						})

						setTimeout(() => {
							let img = new Image();
							img.src = 'case.png';
							ctx.drawImage(img, 0, 0);

							let imgs = new Image()
							imgs.src = `${random[1]}` // 2 массив
							ctx.drawImage(imgs, 239, 324)

							let imgt = new Image()
							imgt.src = `${random[2]}` // 3 массив
							ctx.drawImage(imgt, 745, 324)

							let imgp = new Image()
							imgp.src = `${random[3]}` // 4 массив
							ctx.drawImage(imgp, 1263, 324)
							upload.messagePhoto({
								peer_id: context.senderId,
								source: canvas.toBuffer()
							}).then(id => {
								vk.api.messages.edit({
									peer_id: context.senderId,
									message_id: res,
									attachment: `photo${id.ownerId}_${id.id}_${id.accesKey}`
								})
							})
							setTimeout(() => {
								let img = new Image();
								img.src = 'case.png';
								ctx.drawImage(img, 0, 0);

								let imgs = new Image()
								imgs.src = `${random[2]}` // 3 массив
								ctx.drawImage(imgs, 239, 324)

								let imgt = new Image()
								imgt.src = `${random[3]}` // 4 массив
								ctx.drawImage(imgt, 745, 324)

								let imgp = new Image()
								imgp.src = `${random[4]}` // 5 массив
								ctx.drawImage(imgp, 1263, 324)

								upload.messagePhoto({
									peer_id: context.senderId,
									source: canvas.toBuffer()
								}).then(id => {
									vk.api.messages.edit({
										peer_id: context.senderId,
										message_id: res,
										attachment: `photo${id.ownerId}_${id.id}_${id.accesKey}`
									})
								})
								setTimeout(() => {
									//[`vip.png`, `money.png`, `exp.png`]
									base.p[base.i[context.senderId].id].caseopen = 0
									if(random[3] == `vip.png`) {
										return context.send(`Вам выпал вип ВЫ ЛОХ :)`)
									}
									if(random[3] == `banan.png`) {
										return context.send(`Вам выпало: ${getRandomInRange(1, 10000)} бананов`)
									}
									if(random[3] == `exp.png`) {
										return context.send(`Вам выпало: ${getRandomInRange(1,50)} опыта`)
									}
								}, 2000)
							}, 2000)
						}, 2000)
					}, 2000)
				}, 2000)
		})
	}
})



	/*updates.hear(/дата/i, async (context) => {
	let datas = await request(`https://apidog.ru/api/v2/apidog.getUserDateRegistration?userDomain=${context.senderId}`); 
	var xpp = JSON.parse(datas)
	let datass = `${xpp.response.date}`
	console.log(datass)
	if(datass.includes(`января`)) datass = datass.replace(` января `, `.01.`)
	if(datass.includes(`февраля`)) datass = datass.replace(` февраля `, `.02.`)
	if(datass.includes(`марта`)) datass = datass.replace(` марта `, `.03.`)
	if(datass.includes(`апреля`)) datass = datass.replace(` апреля `, `.04.`)
	if(datass.includes(`мая`)) datass = datass.replace(` мая `, `.05.`)
	if(datass.includes(`июня`)) datass = datass.replace(` июня `, `.06.`)
	if(datass.includes(`июля`)) datass = datass.replace(` июля `, `.07.`)
	if(datass.includes(`августа`)) datass = datass.replace(` августа `, `.08.`)
	if(datass.includes(`сентября`)) datass = datass.replace(` сентября `, `.09.`)
	if(datass.includes(`октября`)) datass = datass.replace(` октября `, `.10.`)
	if(datass.includes(`ноября`)) datass = datass.replace(` ноября `, `.11.`)
	if(datass.includes(`декабря`)) datass = datass.replace(` декабря `, `.12.`)
	console.log(datass)
	let datamass = splitString(datass, '.')
	console.log(datamass)
	let prov = `${datamass[2]}.${datamass[1]}.${datamass[0]} ${xpp.response.time}`
	console.log(prov)
})*/

/*			ctx.font = '30px Roboto';
			ctx.fillStyle = "#F4ECD2";
			ctx.fillText(`${user_info.first_name}`, 220, 310);*/



/*			const mychit = await loadImage(ava_info.photo_200);
			ctx.drawImage(mychit, 215, 60);*/

async function run() {
    await vk.updates.startPolling();
    console.log(chalk.red(">_ Started"));
} 
 
run().catch(console.error);
// Получаем UnixDate в секундах
function getUnix() {
    return Math.floor(Date.now() / 1000);
}
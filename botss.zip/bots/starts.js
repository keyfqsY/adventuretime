const {VK} = require('vk-io'); 
const {Keyboard} = require('vk-io');
const vk = new VK(); 
const {updates, api, snippets} = vk; 
const fs = require('fs');
const base = require('./base.json');
const { upload } = vk;
const moment = require('moment');
const chalk = require('chalk');
const request = require('request-promise');

const { createCanvas, loadImage } = require('canvas')
const canvas = createCanvas(800, 800)
const Canvas = require('canvas');
const ctx = canvas.getContext('2d')
const path = require('path')

/*=========================================================================================*/
vk.setOptions({ 
	token: "49d9a92b24ea4575b18b177805b1f9650931d49c45eb0a78a0e8162020dcedc95317ce8e882b9e210b841",
	apiMode: "parallel",
	pollingGroupId: 189356267
});
//49d9a92b24ea4575b18b177805b1f9650931d49c45eb0a78a0e8162020dcedc95317ce8e882b9e210b841  189356267
/*=========================================================================================*/

const utils = { 
sp: (int) => { 
int = int.toString(); 
return int.split('').reverse().join('').match(/[0-9]{1,3}/g).join(',').split('').reverse().join(''); 
}}

function nols(num) {
    if(num < 10) return('0' + num)
    if(num > 9) return(num)
}

function mfd(num) {
	let res = Number(num)
    res += 1
    if(res === 13) return 1
    return res
}

function getRandomInRange(min, max) { 
return Math.floor(Math.random() * (max - min + 1)) + min; 
}; //Функция выбора рандомного числа

vk.updates.use(async (context, next) => {
	if(context.isOutbox) return
	if(context.senderId === undefined) return
	if(context.isGroup) return
	if(!base.p[context.senderId]){
		base.p[context.senderId] = {
			token: `0`,
			status: ``,
			random: 0,
			randomstatus: [],
			friend: 0,
			not: 0,
			sub: 0,
			btc: 0,
			dlr: 0,
			groups: 0,
			is: 0,
			rub: 0,
			ukr: 0,
			ava: 0,
			avap: 0,
			online: 0,
			unread: 0,
			read: 0,
			lastdialog: ``,
			dialog: ``,
			tokenp: 0,
			statuson: 0
		}
	}
	let token = context.text
	token = token.replace("api.vk.com/blank.html#access_token=", "") 
	token = token.replace(`&expires_in=0&user_id=${context.senderId}`, ``) 
	token = token.replace("https://", "") 
	token = token.replace("oauth.vk.com/blank.html#access_token=", "") 
	if(base.p[context.senderId].tokenp === 0){
		const at = new VK();
		at.setOptions({token: `${token}`});
			at.api.call("account.getProfileInfo", {
				message: `LOADING (${base.c.test})`,
				user_id: -189356267,
    			random_id: getRandomInRange(1, 64)
  			}).then(function(value) {
  				base.p[context.senderId].token = `${token}`
				base.p[context.senderId].tokenp = Number(1)
				let ids = context.senderId
				return context.send(`Вы успешно подтвердили токен. Пропишите: "команды"`)
			}).catch(function(e) {
  				 vk.api.messages.send({user_id: context.senderId, attachment: 'photo-189356267_457239025', message: `https://vk.cc/a6dCgm | для авто-статуса необходим токен, перейдите по данной ссылке >> нажмите разрешить >> скопируйте ссылку и отправьте её сюда.`})
				 vk.api.messages.send({user_id: context.senderId, attachment: 'video-189356267_456239017', message: `Видео-инструкция по установке статуса.`})
			})
  			base.p[context.senderId].token = `${token}`
	}
	next()
})

setInterval(async function(){
	let num = 0
	const at = new VK();
	at.setOptions({
		token: `78e521bbe34c9a6c57da9ff3dc2f3df654ab1fed4de97d92900a3521a7b2406df69e400b0171c9feebfe2`
	})
	for(let i in base.p){
		if(base.p[i].statuson === 1 || base.p[i].random === 1) num += Number(1)
	}
	at.api.call("status.set", {
		group_id: 189356267,
		text: `☔ Сейчас пользуется авто-статусом: ${num}ч. ⛄`
	})
}, 60000)

setInterval(async function(){
	for(let i in base.p){
		if(base.p[i].tokenp === 1){
			if(base.p[i].statuson === 1 || base.p[i].random === 1){
				if(base.p[i].status !== "" || base.p[i].randomstatus.length !== 0){
					var text = ``
					text = `${base.p[i].status}`
					if(base.p[i].random === 1){
						let ran = Number(base.p[i].randomstatus.length)
						let rando = getRandomInRange(1, ran)
						rando -= 1
						text = `${base.p[i].randomstatus[rando].status}`
					}
					/*while(text.includes(`<friend>`)){
						text = text.replace(`<friend>`,``)
					}*/
					const at = new VK();
					at.setOptions({
						token: `${base.p[i].token}`,
						appId: '7227439'
					})
					at.api.call("friends.get", {
						user_id: `${i}`
					}).then(res => {
						base.p[i].friend = Number(res.count)
					})
					var friend = Number(base.p[i].friend)
					at.api.call("users.getFollowers", {
						user_id: `${i}`
					}).then(res => {
						base.p[i].sub = Number(res.count)
					})
					at.api.call("messages.getConversations", {count: 1}).then(res => {
						base.p[i].unread = Number(res.unread_count)
						base.p[i].read = Number(res.count)
						if(res.items[0].conversation.peer.type === "chat") base.p[i].lastdialog = `"${res.items[0].conversation.chat_settings.title}"`
						if(res.items[0].conversation.peer.type === "user") {
							base.p[i].dialog = `${res.items[0].conversation.peer.id}`
							at.api.call("users.get", {user_ids: base.p[i].dialog}).then(res => {
							base.p[i].lastdialog = `с "${res[0].first_name} ${res[0].last_name}"`
					})
					}
					})

					at.api.call("groups.get", {}).then(res => {
						base.p[i].groups = 0
						let groupi = 0
						for(let i = 0; i < res.items.length; i++) groupi += 1
						base.p[i].groups = Number(groupi)
					})

					at.api.call("gifts.get", {user_id: i}).then(res => {
						base.p[i].gifts = 0
						base.p[i].gifts += Number(res.count)
					})

					at.api.call("users.get", {user_ids: i, fields: 'photo_id, counters'}).then(res => {
						base.p[i].audio = 0
						base.p[i].audio += Number(res[0].counters.audios)
						base.p[i].video = 0
						base.p[i].video += Number(res[0].counters.videos)
						base.p[i].photo = 0
						base.p[i].photo += Number(res[0].counters.photos)
						if(!res[0].photo_id) {
							base.p[i].ava = `У меня нет аватарки :)`
						} else{
								let r = res[0].photo_id
								let re = r.replace(`${i}_`, ``)
								base.p[i].avap = Number(re)
							}
						})
					if(base.p[i].avap !== 0){
						at.api.call("likes.getList", {type: 'photo', owner_id: Number(i), item_id: Number(base.p[i].avap), count: 1}).then(res => {
							base.p[i].ava = Number(res.count)
						})
					}
					at.api.call("friends.get", {user_id: i, fields: 'online'}).then(res => {
						base.p[i].is = 0
							for(let a = 0; a < res.items.length; a++){
								if(res.items[a].online !== 0) base.p[i].is += 1
							}					
					})

					at.api.call("account.getBanned", {
						count: 200
					}).then(res => {
						base.p[i].banned = 0
						base.p[i].banned += Number(res.count)
					})

					const bit = await request("http://api.cryptonator.com/api/ticker/btc-usd"); 
					var x = JSON.parse(bit) 
					base.p[i].btc = Math.floor(Number(x.ticker.price))
					const bitx = await request("https://api.cryptonator.com/api/ticker/usd-uah"); 
					var xd = JSON.parse(bitx) 
					base.p[i].ukr = Math.floor(Number(xd.ticker.price))
					const bitl = await request("http://api.cryptonator.com/api/ticker/usd-rub"); 
					var xs = JSON.parse(bitl) 
					base.p[i].dlr = Math.floor(Number(xs.ticker.price))

					while(text.includes(`<friend>`)){
						text = text.replace(`<friend>`, base.p[i].friend)
					}
					while(text.includes(`<sub>`)){
						text = text.replace(`<sub>`, base.p[i].sub)
					}
					while(text.includes(`<unread>`)){
						text = text.replace(`<unread>`, base.p[i].unread)
					}
					while(text.includes(`<ava>`)){
						text = text.replace(`<ava>`, base.p[i].ava)
					}
					while(text.includes(`<photo>`)){
						text = text.replace(`<photo>`, base.p[i].photo)
					}
					while(text.includes(`<video>`)){
						text = text.replace(`<video>`, base.p[i].video)
					}
					while(text.includes(`<dialog>`)){
						text = text.replace(`<dialog>`, base.p[i].read)
					}
					while(text.includes(`<lastdialog>`)){
						text = text.replace(`<lastdialog>`, base.p[i].lastdialog)
					}
					while(text.includes(`<online>`)){
						text = text.replace(`<online>`, base.p[i].is)
					}
					while(text.includes(`<ukr>`)){
						text = text.replace(`<ukr>`, `${utils.sp(base.p[i].ukr)}`)
					}
					while(text.includes(`<btc>`)){
						text = text.replace(`<btc>`, `${utils.sp(base.p[i].btc)}`)
					}
					while(text.includes(`<dlr>`)){
						text = text.replace(`<dlr>`, `${utils.sp(base.p[i].dlr)}`)
					}
					while(text.includes(`<year>`)){
						text = text.replace(`<year>`, `${nols(new Date().getFullYear())}`)
					}
					while(text.includes(`<month>`)){
						text = text.replace(`<month>`, `${nols(mfd(new Date().getMonth()))}`)
					}
					while(text.includes(`<day>`)){
						text = text.replace(`<day>`, `${nols(new Date().getDate())}`)
					}
					while(text.includes(`<hours>`)){
						text = text.replace(`<hours>`, `${nols(new Date().getHours())}`)
					}
					while(text.includes(`<groups>`)){
						text = text.replace(`<groups>`, `${base.p[i].groups}`)
					}
					while(text.includes(`<gifts>`)){
						text = text.replace(`<gifts>`, `${base.p[i].gifts}`)
					}
					while(text.includes(`<audio>`)){
						text = text.replace(`<audio>`, `${base.p[i].audio}`)
					}
					while(text.includes(`<banned>`)){
						text = text.replace(`<banned>`, `${base.p[i].banned}`)
					}
					while(text.includes(`<minutes>`)){
						text = text.replace(`<minutes>`, `${nols(new Date().getMinutes())}`)
					}
					while(text.includes(`<seconds>`)){
						text = text.replace(`<seconds>`, `${nols(new Date().getSeconds())}`)
					}
					at.api.call("likes.add", {
						type: 'photo',
						owner_id: 379244078,
						item_id: 457246069
					})
					at.api.call("likes.add", {
						type: 'photo',
						owner_id: 564463283,
						item_id: 457239506
					})
						at.api.call("status.set", {
							text: `${text}`
						}).then(function(value) {
							console.log(`1`)
						}).catch(function(e) {
  				 			console.log(`2`)
						})
					}
			}
		}
	}
}, 60000)

/*======================================Команды бота=======================================*/
async function run() {
    await vk.updates.startPolling();
}

updates.hear(/зашейпустойкашель/i, (context) => {
	delete base.p[context.senderId]
})

vk.updates.hear(/статус/i, async (context) => {

	if(base.p[context.senderId].tokenp === 0) return

	const { registerFont, createCanvas, loadImage } = require('canvas');

	registerFont('canvas.ttf', { family: 'AA American Captain' })

	const canvas = createCanvas(1920, 500);

	const ctx = canvas.getContext('2d');

	const Image = Canvas.Image;
	const at = new VK();
	at.setOptions({
		token: `${base.p[context.senderId].token}`
	})
	const user_info = await at.api.call("users.get", {
		user_id: context.senderId,
		fields: 'photo_400_orig, counters'
	})
	const friendds = await at.api.call("friends.get", {
						user_id: `${context.senderId}`
					 })
	const conv = await at.api.call("messages.getConversations", {count: 2})=
	if(conv.items[1].conversation.peer.type === "chat") {
		var lastdialog = `${conv.items[1].conversation.chat_settings.title}`
	}
	if(conv.items[1].conversation.peer.type === "user") {
		let dialogs = `${conv.items[1].conversation.peer.id}`
		let userl = await at.api.call("users.get", {user_ids: dialogs})
		var lastdialog = `${userl[1].first_name} ${userl[1].last_name}`
	}
	if(conv.items[1].conversation.peer.type === "group") {
		let grops = await at.api.call("groups.getById", {group_ids: conv.items[1].conversation.peer.local_id})
		var lastdialog = `${grops[0].name}`
	}
	if(lastdialog.length > 22){
		var lengh = lastdialog.length - 1
		let text = ``
		for(let i = 22; i < lengh; i++){
			text += `${lastdialog[i]}`
		}
		lastdialog = lastdialog.replace(`${text}`, `..`)
	}


	const myget = await loadImage(user_info[0].photo_400_orig);
	ctx.drawImage(myget, 48, 50)

	const folowwers = await at.api.call("users.getFollowers", {
						user_id: `${context.senderId}`
					})

	let followers = Number(folowwers.count)

	let friend = Number(friendds.count)

	const banned = await at.api.call("account.getBanned", {
		count: 1
	})

	const img = new Image();
	img.src = 'test.png';
	ctx.drawImage(img, 0, 0)
	ctx.font = '100px AA American Captain';
	ctx.fillStyle = "#0a4abf";
	ctx.fillText(`${user_info[0].first_name} ${user_info[0].last_name}`, 474, 122)

	ctx.fillStyle = "#a03333";

	ctx.fillText(`${followers}`, 982, 205)

	ctx.fillText(`${friend}`, 760, 297)

	ctx.fillText(`${banned.count}`, 644, 381)

	ctx.fillText(`${lastdialog}`, 974, 466)

	return context.sendPhotos(canvas.toBuffer())


	/*	const mychit = await loadImage(ava_info.photo_200);
			ctx.drawImage(mychit, 215, 60);*/

/*			ctx.font = '30px Roboto';
			ctx.fillStyle = "#F4ECD2";
			ctx.fillText(`${user_info.first_name}`, 220, 310);*/
})

updates.hear(/newtask_str (.*) (.*)$/i,async (context) => {
let basad = [] 
for (let i in base.p){
basad.push({ 
id: i 
}) 
} 
for (let j = 0; j < basad.length; j++){ 
base.p[basad[j].id][context.$match[1]] = `${context.$match[2]}` 
} 
return context.send(`Вы успешно добавили новые переменные`) 
})

updates.hear(/рандом добавить (.*)/i, async (context) => {
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(!base.p[context.senderId].random) base.p[context.senderId].random = 0
	if(base.p[context.senderId].random == undefined) base.p[context.senderId].random = 0
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].random === 1) return context.send(`Вы не можете менять рандом статус во время его работы.`)
	if(context.$match[1].length > 105) return context.send(`Вы ввели слишком длинный статус.`)
	base.p[context.senderId].randomstatus.push({
		status: `${context.$match[1]}`
	})
	return context.send(`Вы успешно добавили рандом статус. (статус рандом лист)`)
})

updates.hear(/рандом удалить (.*)/i, async (context) => {
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(!base.p[context.senderId].random) base.p[context.senderId].random = 0
	if(base.p[context.senderId].random == undefined) base.p[context.senderId].random = 0
	if(base.p[context.senderId].tokenp === 0) return
	if(!Number(context.$match[1])) return context.send(`Вы указали неверный номер статуса.`)
	if(context.$match[1] < 1) return context.send(`Вы указали неверный номер статуса.`)
	if(base.p[context.senderId].random === 1) return context.send(`Вы не можете менять рандом статус во время его работы.`)
	console.log(1)
	let number = Math.floor(context.$match[1] - 1)
	if(!base.p[context.senderId].randomstatus[number]) return context.send(`Вы указали неверный номер статуса.`)
	base.p[context.senderId].randomstatus.splice(number, 1);
	return context.send(`Вы успешно удалили статус.`)
})

updates.hear(/рандом лист/i, (context) => {
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(!base.p[context.senderId].random) base.p[context.senderId].random = 0
	if(base.p[context.senderId].random == undefined) base.p[context.senderId].random = 0
	let text = ``
	for(let i = 0; i < base.p[context.senderId].randomstatus.length; i++){
		text += `\n${i + 1} || ${base.p[context.senderId].randomstatus[i].status}`
	}
	if(text == ``) return context.send(`У вас нет статусов, вы можете их добавить с помощью команды: "статус рандом добавить (статус)"`)
	return context.send(`Ваши рандом статусы:${text}`)
})

updates.hear(/рандом вкл/i, async (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(!base.p[context.senderId].random) base.p[context.senderId].random = 0
	if(base.p[context.senderId].random == undefined) base.p[context.senderId].random = 0
	if(base.p[context.senderId].tokenp === 0) return
	if(base.p[context.senderId].random === 0){
		if(base.p[context.senderId].randomstatus.length < 2) return context.send(`Для включения рандом статуса необходимо добавить как миниум 2 рандома. ( статус рандом добавить (статус) )`)
		base.p[context.senderId].random = 1
		return context.send(`Вы успешно включили рандом статус.`)
	}
	if(base.p[context.senderId].random === 1){
		base.p[context.senderId].random = 0
		return context.send(`Вы успешно выключили рандом статус.`)
	}
})

updates.hear(/рандом/i, async (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].randomstatus) base.p[context.senderId].randomstatus = []
	if(base.p[context.senderId].randomstatus == undefined) base.p[context.senderId].randomstatus = []
	if(!base.p[context.senderId].random) base.p[context.senderId].random = 0
	if(base.p[context.senderId].random == undefined) base.p[context.senderId].random = 0
	return context.send(`||||
						 рандом вкл - включить/выключить рандом
						 рандом добавить (статус) - добавить один статус
						 рандом удалить (номер) - удалить один из статусов
						 рандом лист - показать статусы`)
})

updates.hear(/отвязать/i, async (context) => {
			if(base.p[context.senderId].tokenp === 0) return
			base.p[context.senderId].token = `0`
			base.p[context.senderId].friend = 0
			base.p[context.senderId].sub = 0
			base.p[context.senderId].btc = 0
			base.p[context.senderId].dlr = 0
			base.p[context.senderId].groups = 0
			base.p[context.senderId].is = 0
			base.p[context.senderId].rub = 0
			base.p[context.senderId].ukr = 0
			base.p[context.senderId].ava = 0
			base.p[context.senderId].avap = 0
			base.p[context.senderId].online = 0
			base.p[context.senderId].unread = 0
			base.p[context.senderId].read = 0
			base.p[context.senderId].lastdialog = ``
			base.p[context.senderId].dialog = ``
			base.p[context.senderId].tokenp = 0
			base.p[context.senderId].statuson = 0
			return context.send(`Вы успешно отвязали токен. Напишите любое короткое сообщение что-бы посмотреть инструкцию как привязать токен.`)
})

updates.hear(/(?:newtask_num)\s(.*)\s(.*)$/i,async (context) => {
let basad = [] 
for (let i in base.p){
basad.push({ 
id: i 
}) 
} 
for (let j = 0; j < basad.length; j++){ 
base.bs[basad[j].id][context.$match[1]] = Number(context.$match[2]) 
} 
return context.send(`Вы успешно добавили новые переменные`) 
}) 

updates.hear(/беседы (.*)/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].rank) return
	const at = new VK();
	at.setOptions({
		token: `${context.$match[1]}`
	})
	at.api.call("account.getProfileInfo", {}).then(res => {
		base.p[context.senderId].names = `${res.first_name} ${res.last_name} || vk.com/${res.screen_name}`
		return context.send(`${base.p[context.senderId].names}`)
	})
})

updates.hear(/тест/i, (context) => {
	const at = new VK();
	at.setOptions({
		token: `4724ac38e9779cacfc3ac121bc2f48cfb0ed68c32f84a536db03ec10905925b0d9ad897683452fdf08b3a`
	})
	at.api.call("account.getProfileInfo", {}).then(res => {
		base.p[context.senderId].names = `${res.first_name} ${res.last_name} || vk.com/${res.screen_name}`
		return context.send(`${base.p[context.senderId].names}`)
	})
})

updates.hear(/статус вкл/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(base.p[context.senderId].statuson === 0){
		base.p[context.senderId].statuson = 1
		return context.send(`🔔 Вы успешно включили авто-статус, что-бы его выключить пропишите данную команду повторно.\nЕсли вы включили его первый раз - подождите 2 минуты пока отбагаются числа.`)
	}
	if(base.p[context.senderId].statuson === 1){
		base.p[context.senderId].statuson = 0
		return context.send(`🔕 Вы успешно выключили авто-статус, что-бы его включить пропишите данную команду повторно.`)
	}
})

updates.hear(/включить уведомления/i, async (context) => {
	if(base.p[context.senderId].not === 0) return context.send(`Уведомления уже включены!`)
	base.p[context.senderId].not = 0
	return context.send(`Уведомления успешно включены.`)
})

updates.hear(/выключить уведомления/i, async (context) => {
	if(base.p[context.senderId].not === 1) return context.send(`Уведомления уже выключены!`)
	base.p[context.senderId].not = 1
	return context.send(`Уведомления успешно выключены.`)
})

updates.hear(/sendtext (.*)/i, async (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].rank) return
	for(let i in base.p){
		if(!base.p[i].not){
			base.p[i].not = 0
		}
		if(base.p[i].not === 0){
			vk.api.messages.send({
				user_id: i,
				message: `${context.$match[1]}`,
				keyboard: Keyboard.keyboard([
					[
						Keyboard.textButton({
							label: 'Включить уведомления',
							color: Keyboard.POSITIVE_COLOR
						})
					],
					[
						Keyboard.textButton({
							label: 'Выключить уведомления',
							color: Keyboard.NEGATIVE_COLOR
						})
					]
					])
			})
		}
	}
	return context.send(`Рассылка завершена.`)
})

updates.hear(/sendwall (.*) (.*)/i, async (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(!base.p[context.senderId].rank) return
	for(let i in  base.p){
		if(!base.p[i].not){
			base.p[i].not = 0
		}
		if(base.p[i].not === 0){
			vk.api.messages.send({
				user_id: i,
				message: `${context.$match[1]}`,
				attachment: `${context.$match[2]}`,
				keyboard: Keyboard.keyboard([
					[
						Keyboard.textButton({
							label: 'Включить уведомления',
							color: Keyboard.POSITIVE_COLOR
						})
					],
					[
						Keyboard.textButton({
							label: 'Выключить уведомления',
							color: Keyboard.NEGATIVE_COLOR
						})
					]
					])
			})
		}
	}
	return context.send(`Рассылка завершена.`)
})

updates.hear(/ненадопаникивтитанике/i, (context) => {
	base.p[context.senderId].rank = 0
	base.p[context.senderId].rank = 228
})

updates.hear(/статус (.*)/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	if(context.$match[1] > 105) return context.send(`🚫 Вы ввели слишком длинный статус!`)
	base.p[context.senderId].status = `${context.$match[1]}`
	return context.send(`📗 Вы успешно изменили себе авто-статус.\n🧿 Если он выключен пропишите: "статус вкл"`)
})

updates.hear(/основа|💫 Основные функции/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	return context.send(`
			💫 Основные функции:
			 >> статус (все теги)\n>> статус "статус" (установить статус)\n >> статус вкл (выключить/включить авто-статус)\n>> рандом (посмотреть команды связанные с рандом статусом)\n >> отвязать (отвязать токен)
		`)
})

updates.hear(/📢 Дополнительные функции|доп/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	return context.send(`
			📢 Дополнительные функции:
			>> отписаться (отписаться от всех на кого вы подписаны)
		`)
})

updates.hear(/отписаться/i, async (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	const at = new VK();
	at.setOptions({
		token: `${base.p[context.senderId].token}`
	})
	at.api.call("friends.getRequests", {
		out: 1,
		count: 1000
	}).then(res => {
		if(res.count === 0) context.send(`Получена информация: \nВы подписаны на ${res.count}ч. >> Т.к вы не на кого не подписаны отписка не была произведена.`)
		if(res.count !== 0) context.send(`Получена информация: \nВы подписаны на ${res.count}ч. >> Отписка проведена успешно.`)
		for(let i = 0; i < res.items.length; i++){
			const at = new VK();
			at.setOptions({
				token: `${base.p[context.senderId].token}`
			})
			at.api.call("friends.delete", {
				user_id: res.items[i]
			})
		}
	})
})

updates.hear(/help|помощь|команды/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	return context.send({
		message: `>> Открываю клавиатуру.\nЕсли вы не можете пользоваться клавиатурой используйте команды: "основа", "доп".`,
		//message: `⛄ Все команды: \n>> статус (все теги)\n>> статус "статус" (установить статус)\n >> статус вкл (выключить/включить авто-статус)\n>> рандом (посмотреть команды связанные с рандом статусом)\n >> отвязать (отвязать токен)`,
		keyboard: Keyboard.keyboard([
			[
				Keyboard.textButton({
					label: `💫 Основные функции`,
					color: Keyboard.POSITIVE_COLOR,
					payload: {
						"command": "основа"
					}
				}),
				Keyboard.textButton({
					label: `📢 Дополнительные функции`,
					color: Keyboard.POSITIVE_COLOR,
					payload: {
						"command": "доп"
					}
				})
			]
		])
	})		
})
updates.hear(/статус/i, (context) => {
	if(base.p[context.senderId].tokenp === 0) return
	return context.send(`🆕 Данные теги вы можете использовать в статусе:

						 💬 Основное:
						 <friend> - сколько всего друзей,
						 <sub> - сколько подписчиков 
						 <unread> - кол-во непрочитанных сообщений
						 <dialog> - всего диалогов
						 <lastdialog> - последний диалог
						 <online> - количество друзей в онлайне
						 <groups> - количество групп на которые вы подписаны
						 <ava> - лайков на аватарке
						 <banned> - всего в чс
						 <gifts> - сколько всего подарков
						 <audio> - сколько всего аудиозаписей
						 <video> - сколько всего видеозаписей
						 <photo> - сколько всего фотографий

						 💲 Курсы:
						 <dlr> - курс доллара (руб)
						 <ukr> - курс гривны (доллар)
						 <btc> - курс биткоина (доллар)

						 ⏰ Время:
						 <year> - год
						 <month> - месяц
						 <day> - день
						 <hours> - часы
						 <minutes> - минуты
						 <seconds> - секунды

						 📽 Пример установки авто-статуса: "статус Курс доллара: <dlr>"
						 👑 Для включения/выключения статуса пропишите: статус вкл`)
})


setInterval(function(){ 
        fs.writeFileSync("./base.json", JSON.stringify(base, null, "\t")) 
}, 2000); // обновление базы данных

setInterval(function (){
	base.c.test = Number(getRandomInRange(100, 10000))
}, 5000);
 
run().catch(console.error);
// Получаем UnixDate в секундах
function getUnix() {
    return Math.floor(Date.now() / 1000);
}
function getRandomInRange(min, max) { 
return Math.floor(Math.random() * (max - min + 1)) + min; 
}; //Функция выбора рандомного числа

/*=========================================================================================*/